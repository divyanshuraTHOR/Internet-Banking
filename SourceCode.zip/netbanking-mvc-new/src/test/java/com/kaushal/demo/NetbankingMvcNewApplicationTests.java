package com.kaushal.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetbankingMvcNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
