package com.kaushal.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetbankingMvcNewApplication {

	public static void main(String[] args) {
		SpringApplication.run(NetbankingMvcNewApplication.class, args);
	}

}
